package ie.wit.ui.equipment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.fragment_equipment.*
import ie.wit.R
import ie.wit.models.EquipAdapter
import ie.wit.models.Equiplist


class EquipmentFragment : Fragment() {


    private lateinit var equipAdapter: EquipAdapter

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        equipAdapter = EquipAdapter(mutableListOf())

        eqlistdis.adapter = equipAdapter
        //layout manager-defines how item displays, properly in list view.
        eqlistdis.layoutManager = LinearLayoutManager(context)

        return inflater.inflate(R.layout.fragment_equipment, container, false)


}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //button activity
        EquipSave.setOnClickListener {
            val equipName= EquipTitle.text.toString()
            if (equipName.isNotEmpty()){
                val equipment = Equiplist(equipName)
                equipAdapter.addEquipList(equipment)
                EquipTitle.text.clear()
            }
        }
        EquipDelete.setOnClickListener {
            //delete was already defined in the adapter
            equipAdapter.deleteEquip()
        }
    }

}
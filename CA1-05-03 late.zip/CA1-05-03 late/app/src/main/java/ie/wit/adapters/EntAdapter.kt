package ie.wit.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ie.wit.R
import ie.wit.models.EntModel
import kotlinx.android.synthetic.main.entranceitem.view.*
//import kotlinx.android.synthetic.main.fragment_entrances.view.*

class EntAdapter constructor(private var entrances: ArrayList<EntModel>)
    : RecyclerView.Adapter<EntAdapter.EntInfo>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntInfo {
        return EntInfo(LayoutInflater.from(parent.context).inflate(
                R.layout.entranceitem,
                parent,
                false))}

    override fun onBindViewHolder(holder: EntInfo, position: Int) {
        val entrance = entrances[holder.adapterPosition]
        holder.bind(entrance)}

    override fun getItemCount(): Int = entrances.size
    class EntInfo constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(entrance : EntModel){
            itemView.entranceName.text = entrance.entranceTitle
            itemView.entranceType.text = entrance.entrgroup }}
    }


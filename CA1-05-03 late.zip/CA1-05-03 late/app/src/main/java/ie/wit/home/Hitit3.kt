package ie.wit.home

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import ie.wit.R
import ie.wit.models.EntStore

class Hitit3 : AppCompatActivity() {

//    lateinit var app: Hitit3
    private lateinit var appBarConfiguration: AppBarConfiguration

    lateinit var entranceStore: EntStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //accidentally defined val for nav_view twice.
        val toolbar: Toolbar = findViewById(R.id.nav_view)
        setSupportActionBar(toolbar)

            val navController = findNavController(R.id.nav_host_fragment)
            // Passing each menu ID as a set of Ids because each
            // menu should be considered as top level destinations.
            val appBarConfiguration = AppBarConfiguration(
                setOf(
                    R.id.nav_home, R.id.nav_Equipment, R.id.nav_entrances, R.id.nav_history
                ))
            setupActionBarWithNavController(navController, appBarConfiguration)
            toolbar.setupWithNavController(navController)
        }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
    }
package ie.wit.models

data class Equiplist(
        val EquipName: String,
        var isChecked: Boolean = false
)

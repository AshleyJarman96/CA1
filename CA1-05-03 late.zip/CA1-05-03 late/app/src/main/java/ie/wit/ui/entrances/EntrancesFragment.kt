package ie.wit.ui.entrances

import android.os.Bundle
import android.text.Editable
import android.view.*
import androidx.fragment.app.Fragment
import ie.wit.R
import ie.wit.home.Hitit3
import ie.wit.models.EntModel
import ie.wit.models.EntStore
import kotlinx.android.synthetic.main.fragment_entrances.*
import kotlinx.android.synthetic.main.fragment_entrances.view.*

class EntrancesFragment : Fragment() {

    lateinit var app: Hitit3
    lateinit var entranceStore: EntStore

    //displaying code
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val root = inflater.inflate(R.layout.fragment_entrances, container, false)
        setButtonListener(root)
        return root
    }

        fun setButtonListener( layout: View) {
            layout.entranceAdd.setOnClickListener {
                //don't need progress bar for this

                //payment method=entrgroup
                val entrgroup = if (layout.entranceType.checkedRadioButtonId == R.id.RButtD) "Door" else "Window"
                //functions of progress bar not needed in current iteration of app
                entranceStore.create(EntModel(
                        entrgroup = entrgroup,
                        entranceTitle = entranceTitle as @RawValue Editable))

            }
            }
        }
//do not want a report of previous activity accessible by user for security purposes

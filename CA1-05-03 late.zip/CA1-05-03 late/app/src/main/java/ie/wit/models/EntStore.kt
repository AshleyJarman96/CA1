package ie.wit.models

interface EntStore {
    fun findAll() : List<EntModel>
    fun findById(id: Long) : EntModel?
    fun create(entrance : EntModel)
//Functions and classes to be added later
    //fun update(entrances: EntModel)
    //fun delete(entrances: EntModel)
}
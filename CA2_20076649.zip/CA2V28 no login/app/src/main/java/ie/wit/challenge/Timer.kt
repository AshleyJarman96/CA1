package ie.wit.challenge

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import ie.wit.Page1
import ie.wit.R
import ie.wit.databinding.TimerBinding
import ie.wit.challenge.Constants.TIMER_INTERVAL
import ie.wit.challenge.Utility.getFormattedStopWatch
import ie.wit.fragments.CoverupFragment
import ie.wit.fragments.about.AboutChecklist


class Timer : AppCompatActivity() {
    private var binding: TimerBinding? = null

    //this makes the handler run repeatedly
    private val mInterval = TIMER_INTERVAL

    //handler initializes when we start the clock
    private var mHandler: Handler? = null

    //keeps the sum of seconds passed
    private var timeInSeconds = 0L

    //keeps an eye on the button
    private var startButtonClicked = false

    val aboutChecklist = AboutChecklist()
    val cuFragment = CoverupFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.timer)

        val CvrBtn: Button = findViewById(R.id.CUbutton)
        CvrBtn.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.FL,cuFragment)
                //making sure we can undo
                addToBackStack(null)
                commit()
            }}
        val aboutBtn: Button = findViewById(R.id.Abbutton)
        CvrBtn.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.FL,aboutChecklist)
                //making sure we can undo
                addToBackStack(null)
                commit()
            }}

        binding = TimerBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        initStopWatch()
        binding!!.rsButton.setOnClickListener {
            stopTimer()
            resetTimerView()
        }
        val hbutton: Button = findViewById(R.id.Hbutton)
        hbutton.setOnClickListener{
            val intent = Intent(this, Page1::class.java)
            //sending the user to home
            startActivity(intent)}
    }

    private fun initStopWatch() {
        binding?.tvCountdown?.text =
            getString(R.string.timerTime)
    }

    private fun resetTimerView() {
        timeInSeconds = 0
        startButtonClicked = false
        binding?.stButton?.setBackgroundColor(
            ContextCompat.getColor(
                this,
                R.color.teal_700
            )
        )
        binding?.stButton?.setText(R.string.start)
        initStopWatch()
    }

    //function calls different functions depending on buttons
    fun startOrStopButtonClicked(v: View) {
        if (!startButtonClicked) {
            startTimer()
            startTimerView()
        } else {
            stopTimer()
            stopTimerView()
        }
    }

    //button clicked we start the timer.
    private fun startTimer() {
        mHandler = Handler(Looper.getMainLooper())
        mStatusChecker.run()
    }

    //and change the view, like button colour and text
    private fun startTimerView() {
        binding?.stButton?.setBackgroundColor(
            ContextCompat.getColor(
                this,
                R.color.colorPrimary
            )
        )
        binding?.stButton?.setText(R.string.stop)
        startButtonClicked = true
    }

    private fun stopTimer() {
        mHandler?.removeCallbacks(mStatusChecker)
    }

    //stops the timer and destorys the view
    private fun stopTimerView() {
        binding?.stButton?.setBackgroundColor(
            ContextCompat.getColor(
                this,
                R.color.teal_700
            )
        )
        binding?.stButton?.setText(R.string.resume)
        startButtonClicked = false
    }

    private var mStatusChecker: Runnable = object : Runnable {
        override fun run() {
            try {
                timeInSeconds += 1
                updateStopWatchView(timeInSeconds)
            } finally {
                // 100% guarantee that this always happens, even if
                // your update method throws an exception
                mHandler!!.postDelayed(this, mInterval.toLong())
            }
        }
    }

    private fun updateStopWatchView(timeInSeconds: Long) {
        val formattedTime = getFormattedStopWatch((timeInSeconds * 1000))
        Log.e("formattedTime", formattedTime)
        binding?.tvCountdown?.text = formattedTime
    }



    override fun onDestroy() {
        super.onDestroy()
        stopTimer()
    }
}



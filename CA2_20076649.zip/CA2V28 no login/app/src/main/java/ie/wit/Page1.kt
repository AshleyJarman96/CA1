package ie.wit

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import ie.wit.target.Checklist
import com.google.android.material.floatingactionbutton.FloatingActionButton
import ie.wit.challenge.Timer
import ie.wit.fragments.CoverupFragment
import ie.wit.fragments.about.AboutFragment
import ie.wit.fragments.social.SocialFragment
import ie.wit.fragments.torch.TorchFragment

class Page1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.page1)

        val aboutFragment = AboutFragment()
        val torchFragment = TorchFragment()
        val coverupFragment = CoverupFragment()

//makes landing fragment within frame layout, the aboutfragment
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.FLfrag,aboutFragment)
            commit()
        }

        //cover fragment button
        val nbutton1: Button = findViewById(R.id.Nbtn11)
        nbutton1.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.FLfrag,coverupFragment)
                //making sure we can undo
                addToBackStack(null)
                commit()
            }}

        //torch fragment button
        val nbutton2: Button = findViewById(R.id.Nbtn12)
        nbutton2.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.FLfrag,torchFragment)
                //making sure we can undo
                addToBackStack(null)
                commit()
            }}
        //about fragment button
        val nbutton3: Button = findViewById(R.id.Nbtn13)
        nbutton3.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.FLfrag,aboutFragment)
                //making sure we can undo
                addToBackStack(null)
                commit()
            }}

       val fab1: FloatingActionButton = findViewById(R.id.fab1)
        fab1.setOnClickListener{
            val intent = Intent(this, Checklist::class.java)
            //sending the user to maps
            startActivity(intent)}

        val fab2: FloatingActionButton = findViewById(R.id.fab2)
        fab2.setOnClickListener{
            val intent = Intent(this, Timer::class.java)
            //sending the user to edit checklist
            startActivity(intent)}

        val fab3: FloatingActionButton = findViewById(R.id.fab3)
        fab3.setOnClickListener{
            val intent = Intent(this, Logout::class.java)
            //sending the user to edit checklist
            startActivity(intent)}


    }


}
package ie.wit.adapters

import android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
import android.text.Editable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import ie.wit.R
import ie.wit.models.Equiplist
import kotlinx.android.synthetic.main.equipitem.view.*

class EquipAdapter
//constructor of class
( private val equipments: MutableList<Equiplist>
        ) : RecyclerView.Adapter<EquipAdapter.EquipViewHolder>() {
 class EquipViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    //the below override functions were called with shortcut key "ctrl + i"
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EquipViewHolder {
//define what items in list looks like
        //parent=viewgroup
        return EquipViewHolder( LayoutInflater.from(parent.context).inflate(
            R.layout.equipitem,
            parent
        ))
    }

    //add & delete buttons-what happens
    fun addEquipList(equipment: Equiplist){
        equipments.add(equipment)
        notifyItemInserted(equipments.size -1)
    }
    fun deleteEquip(){
        equipments.removeAll { equipment->
            //retrieves full
            equipment.isChecked
        }
        //notify adapter of the change
        notifyDataSetChanged()
    }


    private fun toggleStrikeThrough(EquipName : TextView, isChecked: Boolean){
        if (isChecked){
            EquipName.paintFlags = EquipName.paintFlags or STRIKE_THRU_TEXT_FLAG
        } else {
            EquipName.paintFlags = EquipName.paintFlags and STRIKE_THRU_TEXT_FLAG.inv()
        }
    }
//type mismatch below in EquipName
private fun String.toEditable(): Editable = Editable.Factory.getInstance().newEditable(this)

//setting data of list to views
    override fun onBindViewHolder(holder: EquipViewHolder, position: Int) {
        val curEquiplist = equipments[position]
    //below apply function saves from having to repeatedly call the same values
    holder.itemView.apply {
        EquipName.text = curEquiplist.EquipName.toEditable()
        gotbox.isChecked = curEquiplist.isChecked
        //button control of checking
    toggleStrikeThrough(EquipName, curEquiplist.isChecked)
        gotbox.setOnCheckedChangeListener { _, isChecked ->
            toggleStrikeThrough(EquipName,isChecked)
            //making sure that it checks/unchecks correctly
            curEquiplist.isChecked = !curEquiplist.isChecked
        }
    }}

    override fun getItemCount(): Int {
    return equipments.size
    }
}
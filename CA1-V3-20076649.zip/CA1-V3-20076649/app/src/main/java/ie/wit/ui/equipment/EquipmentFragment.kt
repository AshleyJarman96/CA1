package ie.wit.ui.equipment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import ie.wit.R
import ie.wit.adapters.EquipAdapter
import ie.wit.main.Hitit3
import ie.wit.models.Equiplist
import kotlinx.android.synthetic.main.fragment_equipment.*


class EquipmentFragment : Fragment() {


    lateinit var app: Hitit3
    private lateinit var equipAdapter: EquipAdapter


    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {

        equipAdapter = EquipAdapter(mutableListOf())

        eqlistdis.adapter = equipAdapter
        //layout manager-defines how item displays, properly in list view.
        eqlistdis.layoutManager = LinearLayoutManager(context)

        val root = inflater.inflate(R.layout.fragment_equipment, container, false)
        return root
    }


    companion object {
        @JvmStatic
        fun newInstance() =
                EquipmentFragment().apply {
                    arguments = Bundle().apply {}
                } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //button activity
        EquipSave.setOnClickListener {
            val equipName= EquipTitle.text.toString()
            if (equipName.isNotEmpty()){
                val equipment = Equiplist(equipName)
                equipAdapter.addEquipList(equipment)
                EquipTitle.text.clear()
            }
        }
        EquipDelete.setOnClickListener {
            //delete was already defined in the adapter
            equipAdapter.deleteEquip()
        }
    }

}
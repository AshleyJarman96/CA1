package ie.wit.ui.entrances

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.view.*
import androidx.fragment.app.Fragment
import ie.wit.R
import ie.wit.main.Hitit3
import ie.wit.models.EntModel
import ie.wit.models.EntStore
import kotlinx.android.synthetic.main.equipitem.*
import kotlinx.android.synthetic.main.fragment_entrances.*
import kotlinx.android.synthetic.main.fragment_entrances.view.*

class EntrancesFragment : Fragment() {

    lateinit var app: Hitit3
    private lateinit var entranceStore: EntStore
    lateinit var loader : AlertDialog

    //displaying code
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val root = inflater.inflate(R.layout.fragment_entrances, container, false)
        setButtonListener(root)
     //   loader = createLoader(activity!!)
        return root
    }

    companion object {
        @JvmStatic
        fun newInstance() =
                EntrancesFragment().apply {
                    arguments = Bundle().apply {}
                }
    }

        private fun setButtonListener(layout: View) {
            layout.entranceAdd.setOnClickListener {
                //don't need progress bar for this

                //payment method=entrgroup
                val entrgroup = if (layout.entranceType.checkedRadioButtonId == R.id.RButtD) "Door" else "Window"
                //functions of progress bar not needed in current iteration of app
                entranceStore.create(EntModel(
                        entrgroup = entrgroup,
                        entranceTitle = entranceTitle as @RawValue Editable))

            }
        }
//Data Management
    /*
    Callback<List<EntModel>>
override fun onFailure(call: Call<List<EntModel>>, t: Throwable){
    info("Retrofit Error : $t.message")
    serviceUnavailableMessage(activity!!)
    hideLoader(loader)
}
    override fun onResponse(
        call: Call<List<EntModel>>,
        response: Responsecall: Call<List<EntModel>>,)
    {    serviceAvailableMessage(activity!!)
        info("Retrofit JSON = $response.raw()")
        app.entranceStore.entrances = response.body() as ArrayList<EntModel>
        updateUI()
        hideLoader(loader)}

    fun updateUI() {
        entranceTitle = app.EntStore.findAll().sumBy{it.entrgroup}
        entranceTitle.text = format("$ $entranceTitle"

     */
    }

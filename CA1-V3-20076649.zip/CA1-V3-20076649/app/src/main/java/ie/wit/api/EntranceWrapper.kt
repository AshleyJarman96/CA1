package ie.wit.api

import com.google.gson.GsonBuilder
import ie.wit.models.EntModel
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

class EntranceWrapper {
    var message: String? = null
    var data: EntModel? = null
}
interface EntranceService {
    @GET("/entrances")
    fun getall(): Call<List<EntModel>>

    @GET("/entrances/{id}")
    fun get(@Path("id") id: String): Call<EntModel>

    @DELETE("/entrances/{id}")
    fun delete(@Path("id") id: String): Call<EntranceWrapper>

    @POST("/entrances")
    fun post(@Body entrance: EntModel): Call<EntranceWrapper>

    @PUT("/entrances/{id}")
    fun put(@Path("id") id: String,
            @Body entrance: EntModel
    ): Call<EntranceWrapper>

    companion object {

//        val serviceURL = "https://donationweb-hdip-server.herokuapp.com"

        fun create() : EntranceService {

            val gson = GsonBuilder().create()

            val okHttpClient = OkHttpClient.Builder()
                .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .build()

            val retrofit = Retrofit.Builder()
               // .baseUrl(serviceURL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(okHttpClient)
                .build()
            return retrofit.create(EntranceService::class.java)
        }
    }
}
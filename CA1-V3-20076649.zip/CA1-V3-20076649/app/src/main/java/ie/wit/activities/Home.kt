package ie.wit.activities

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.navigation.ui.AppBarConfiguration
import com.google.android.material.navigation.NavigationView
import ie.wit.R
import ie.wit.ui.Greet
import ie.wit.ui.entrances.EntrancesFragment.Companion.newInstance
import ie.wit.ui.equipment.EquipmentFragment
import ie.wit.ui.report.HistoryFragment
import kotlinx.android.synthetic.main.app_bar_home.*
import kotlinx.android.synthetic.main.landing.*
import org.jetbrains.anko.toast

class Home : AppCompatActivity(),
        NavigationView.OnNavigationItemSelectedListener {

    lateinit var ft: FragmentTransaction

    //    lateinit var app: Hitit3
    private lateinit var appBarConfiguration: AppBarConfiguration


    //appearance

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //undecided on using activity main/landing
        setContentView(R.layout.landing)

        //accidentally defined val for nav_view twice.
    //    val toolbar: Toolbar = findViewById(R.id.nav_view)
      //  setSupportActionBar(toolbar)
    nav_view.setNavigationItemSelectedListener(this)

    val toggle = ActionBarDrawerToggle(
            this, drawer_layout, toolbar,
            R.string.open,
            R.string.close
    )
    drawer_layout.addDrawerListener(toggle)
    toggle.syncState()

    ft = supportFragmentManager.beginTransaction()

    val fragment = newInstance()
    ft.replace(R.id.nav_host_fragment, fragment)
    ft.commit()
}

    //navigation

override fun onNavigationItemSelected(item: MenuItem): Boolean {

    when (item.itemId) {
        R.id.nav_home -> navigateTo(Greet.newInstance())
        R.id.nav_entrances -> navigateTo(newInstance())
        R.id.nav_Equipment -> navigateTo(EquipmentFragment.newInstance())
        R.id.nav_history -> navigateTo(HistoryFragment.newInstance())

        else -> toast("You Selected Something Else")
    }
    drawer_layout.closeDrawer(GravityCompat.START)
    return true }

override fun onCreateOptionsMenu(menu: Menu): Boolean {
    menuInflater.inflate(R.menu.home_drawer, menu)
    return true}

override fun onBackPressed() {
    if (drawer_layout.isDrawerOpen(GravityCompat.START))
        drawer_layout.closeDrawer(GravityCompat.START)
    else
        super.onBackPressed() }

private fun navigateTo(fragment: Fragment) {
    supportFragmentManager.beginTransaction()
            .replace(R.id.nav_host_fragment, fragment)
            .addToBackStack(null)
            .commit()

}
}
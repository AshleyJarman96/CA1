package ie.wit.ui.report
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import ie.wit.R
import ie.wit.adapters.EntAdapter
import ie.wit.main.Hitit3
import ie.wit.models.EntModel
import kotlinx.android.synthetic.main.fragment_history_list.view.*

class HistoryFragment : Fragment() {

    lateinit var app: Hitit3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = activity?.application as Hitit3
    }
 override fun on
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_history_list, container, false)
        activity?.title = getString(R.string.R)

        root.recyclerView.layoutManager = LinearLayoutManager(activity)
        root.recyclerView.adapter = EntAdapter(app.entranceStore.findAll() as ArrayList<EntModel>)
        return root
    }
    companion object {
        @JvmStatic
        fun newInstance() =
                HistoryFragment().apply {
                    arguments = Bundle().apply {}
                }
    }
}
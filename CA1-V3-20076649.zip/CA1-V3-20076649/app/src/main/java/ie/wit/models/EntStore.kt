package ie.wit.models

interface EntStore {
    var entrances: ArrayList<EntModel>

    fun findAll() : List<EntModel>
    fun create(entrance : EntModel)
}
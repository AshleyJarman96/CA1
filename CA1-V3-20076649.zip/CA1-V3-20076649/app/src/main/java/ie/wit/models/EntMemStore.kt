package ie.wit.models

import android.util.Log

var lastId = 0L

internal fun getId(): Long {
    return lastId++
}

class EntMemStore : EntStore {

    override var entrances = ArrayList<EntModel>()

    override fun findAll(): List<EntModel> {
        return entrances
    }

    //override
    fun findById(id:Long) : EntModel? {
        val foundEnt: EntModel? = entrances.find { it.id == id }
        return foundEnt
    }

    override fun create(entrance: EntModel) {
        entrance.id = getId()
        entrances.add(entrance)
        logAll()
    }

    fun logAll() {
        Log.v("Entrance","** Entrance List **")
        entrances.forEach { Log.v("Entrance","$it") }
    }
}

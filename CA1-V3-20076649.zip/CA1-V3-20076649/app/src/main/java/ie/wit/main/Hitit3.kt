package ie.wit.main

import android.app.Application
import ie.wit.models.EntMemStore
import ie.wit.models.EntStore

class Hitit3 : Application() {

    lateinit var app: Hitit3
    lateinit var entranceStore: EntStore


    override fun onCreate() {
        super.onCreate()

    entranceStore = EntMemStore()
    }
}
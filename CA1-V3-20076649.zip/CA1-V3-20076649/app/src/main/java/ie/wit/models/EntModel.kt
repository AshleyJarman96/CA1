package ie.wit.models

import android.os.Parcelable
import android.text.Editable
import kotlinx.android.parcel.Parcelize
import kotlinx.android.parcel.RawValue

@Parcelize
data class EntModel(
        var id: Long = 0,
        val entrgroup: String= "N/A",
        val entranceTitle: @RawValue Editable
        ) : Parcelable




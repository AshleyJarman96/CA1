package ie.wit.models

data class Equiplist(
        val EquipName: String,
        //checked box cant be a val so it's a var.
        var isChecked: Boolean = false
)

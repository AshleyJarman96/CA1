package ie.wit.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import ie.wit.R
import ie.wit.ui.about.AboutFragment
import ie.wit.ui.checklist.ChecklistFragment
import ie.wit.ui.torch.TorchFragment

class Page1 : AppCompatActivity() {


  //  private lateinit var binding: Page1Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.loading)
/**
        binding = Page1Binding.inflate(layoutInflater)
        setContentView(binding.root)
        val animation = AnimationUtils.loadAnimation(this, R.anim.circle_explosion_anim).apply {
            duration = 700
            interpolator = AccelerateDecelerateInterpolator()
**/
            val aboutFragment = AboutFragment()
        val checklistFragment = ChecklistFragment()
        val torchFragment = TorchFragment()

//makes landing fragment within frame layout, the aboutfragment
supportFragmentManager.beginTransaction().apply {
    replace(R.id.FLfrag,aboutFragment)
    commit()
}
        //checklist fragment button
        val nbutton1: Button = findViewById(R.id.Nbtn11)
        nbutton1.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
            replace(R.id.FLfrag,checklistFragment)
            //making sure we can undo
            addToBackStack(null)
            commit()
        }}

        //torch fragment button
        val nbutton2: Button = findViewById(R.id.Nbtn12)
        nbutton2.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.FLfrag,torchFragment)
                //making sure we can undo
                addToBackStack(null)
                commit()
            }}

        val fab1: FloatingActionButton = findViewById(R.id.fab1)
        fab1.setOnClickListener{
            val intent = Intent(this, Logout::class.java)
            //sending the user to Logout
            startActivity(intent)}

        val fab2: FloatingActionButton = findViewById(R.id.fab2)
        fab2.setOnClickListener{
            val intent = Intent(this, Checklist::class.java)
            //sending the user to edit checklist
            startActivity(intent)}

       /**     binding.fab.setOnClickListener {
                binding.fab.isVisible = false
                binding.circle.isVisible = true
                binding.circle.startAnimation(animation) {
                    // display your fragment
                    binding.root.setBackgroundColor(ContextCompat.getColor(this, R.color.purple_500))
                    binding.circle.isVisible = false
                }
            }**/

    }


}
package ie.wit.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import ie.wit.R
import ie.wit.ui.checklist.CheckListAdapter
import ie.wit.ui.checklist.ObjStore
import kotlinx.android.synthetic.main.fragment_checklist.*

class Checklist : AppCompatActivity() {

    private lateinit var CheckListAdapter: CheckListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.checklistmain)
        CheckListAdapter = CheckListAdapter(mutableListOf())

        rvObjList.adapter = CheckListAdapter
        rvObjList.layoutManager = LinearLayoutManager(this)

        btnAddObj.setOnClickListener {
            val ObjNameval = etObjName.text.toString()
            if(ObjNameval.isNotEmpty()) {
                val todo = ObjStore(ObjNameval)
                CheckListAdapter.addTodo(todo)
                etObjName.text.clear()
            }
        }
        btnDelObj.setOnClickListener {
            CheckListAdapter.deleteobjItem()
        }
    }
}
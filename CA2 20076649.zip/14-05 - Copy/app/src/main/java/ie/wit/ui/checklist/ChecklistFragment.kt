package ie.wit.ui.checklist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import ie.wit.R
import ie.wit.main.Hitit3
import kotlinx.android.synthetic.main.fragment_checklist.*
import kotlinx.android.synthetic.main.fragment_checklist.view.*
import org.jetbrains.anko.AnkoLogger

class ChecklistFragment : Fragment(), AnkoLogger {

    lateinit var loader: AlertDialog
    lateinit var app: Hitit3
    private lateinit var CheckListAdapter: CheckListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = activity?.application as Hitit3
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val root = inflater.inflate(R.layout.fragment_checklist, container, false)

        CheckListAdapter = CheckListAdapter(mutableListOf())
        //layout manager-defines how item displays, properly in list view.

        root.rvObjList.setLayoutManager(LinearLayoutManager(activity))
        root.rvObjList.adapter = CheckListAdapter(app.objects)


        rvObjList.adapter = CheckListAdapter
        rvObjList.layoutManager = LinearLayoutManager(context)


            btnAddObj.setOnClickListener {
            val objNameval = etObjName.text.toString()
            if (objNameval.isNotEmpty()) {
                val todo = ObjStore(objNameval)
                CheckListAdapter.addTodo(todo)
                etObjName.text.clear()
            }
        }
        btnDelObj.setOnClickListener {
            CheckListAdapter.deleteobjItem()
        }
    return root}

    companion object {
        @JvmStatic
        fun newInstance() =
            ChecklistFragment().apply {
                arguments = Bundle().apply {} } }

}
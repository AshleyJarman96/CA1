package ie.wit.main

import android.app.Application
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import ie.wit.ui.checklist.ObjStore
import org.jetbrains.anko.AnkoLogger

class Hitit3 : Application(), AnkoLogger {

    lateinit var auth: FirebaseAuth
    lateinit var database: DatabaseReference
    var objects = ArrayList<ObjStore>()
    lateinit var app: Hitit3

    override fun onCreate() {
        super.onCreate()

    }
}
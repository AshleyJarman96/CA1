package ie.wit.ui.checklist

data class ObjStore(
    val title: String,
    var isChecked: Boolean = false
)